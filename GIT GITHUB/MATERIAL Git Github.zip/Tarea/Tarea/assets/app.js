

$("button").on("click",function(){
  $(this).prev().slideToggle(300);
});
