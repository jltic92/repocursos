 # Pasos para instalar
 Seguir estos pasos:
 ---

yarn install
 ---

 2. Ejecutar comando:
 ---
 npm start
 ---

 ## Notas
 Debemos de tener en cuanta que omitiremos:
 node_modules