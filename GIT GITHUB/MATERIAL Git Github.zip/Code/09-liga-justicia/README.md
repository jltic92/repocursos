# Objetivos de la repositorio

Este proyecto se encarga de manejar los planes de la liga de la justicia


## Estos cambios son nuevos desde GitHub
## Estos cambios son nuevos desde mi repositorio local.
