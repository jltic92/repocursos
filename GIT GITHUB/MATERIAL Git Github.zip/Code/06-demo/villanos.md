1.- Flash reverso
2.- Doomsday

#Notas.